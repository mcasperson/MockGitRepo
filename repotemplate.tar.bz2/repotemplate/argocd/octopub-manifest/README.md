The yaml files in this directory are app-of-apps. They each reference an application deploying a helm chart from a subfolder under the `application` directory.

The purpose of this directory structure is to allow the `Update Argo CD Application Manifests` step to take the template application yaml file and save it over the existing application yaml file in the `application` directory.

The newly saved file can then reference the helm chart directory.

This works around the requirement of the `Update Argo CD Application Manifests` step to save template files in the `path` of the application that links to the step. Without this level of indirection, template files could only be saved into the helm chart directory, which is not desirable.